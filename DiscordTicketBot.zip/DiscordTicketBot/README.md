# 🎫 Bot de Tickets Discord - Astral Store

Bot completo de tickets para Discord desenvolvido com discord.js v14. Sistema profissional de atendimento com persistência em JSON e keep-alive integrado.

## 📋 Funcionalidades

✅ **Sistema de Setup Completo**
- Comando `/setup` para configurar cargo de suporte e categoria de tickets
- Configurações salvas automaticamente em `config.json`

✅ **Painel de Tickets Personalizado**
- Comando `/ticket` para enviar painel customizado
- Embed com informações da Astral Store
- Botão interativo para criar tickets

✅ **Gestão de Tickets**
- Criação automática de canais privados (`ticket-[userid]`)
- Permissões automáticas (usuário + suporte)
- Botão para fechar ticket com confirmação
- Exclusão automática após 5 segundos

✅ **Sistema de Persistência**
- Todas as configurações salvas em `config.json`
- Carregamento automático ao reiniciar o bot
- Suporte para múltiplos servidores

✅ **Keep-Alive Integrado**
- Servidor HTTP com Express.js
- Endpoint de status do bot
- Logs automáticos a cada 5 minutos
- Evita hibernação em serviços cloud (Replit, Render, Railway)

## 🚀 Instalação

### 1. Pré-requisitos

- Node.js 18 ou superior
- Uma aplicação Discord Bot criada no [Discord Developer Portal](https://discord.com/developers/applications)

### 2. Obter TOKEN e CLIENT_ID

1. Acesse o [Discord Developer Portal](https://discord.com/developers/applications)
2. Crie uma nova aplicação ou selecione uma existente
3. Vá em **Bot** → Clique em **Reset Token** → Copie o token
4. Vá em **OAuth2** → Copie o **CLIENT ID**
5. Em **Bot** → Ative as seguintes **Privileged Gateway Intents**:
   - ✅ Server Members Intent
   - ✅ Message Content Intent

### 3. Convidar o Bot para seu Servidor

Use este link (substitua `SEU_CLIENT_ID` pelo ID copiado):

```
https://discord.com/api/oauth2/authorize?client_id=SEU_CLIENT_ID&permissions=8&scope=bot%20applications.commands
```

### 4. Configurar o Projeto

**Clone ou baixe este repositório:**

```bash
git clone <url-do-repositorio>
cd discord-ticket-bot
```

**Instale as dependências:**

```bash
npm install
```

**Configure as variáveis de ambiente:**

Crie um arquivo `.env` na raiz do projeto:

```env
TOKEN=seu_token_do_bot_aqui
CLIENT_ID=seu_client_id_aqui
```

### 5. Executar o Bot

```bash
npm start
```

Você verá:

```
🤖 Bot online como SeuBot#1234
📊 Servidores: 1
✅ Comandos registrados com sucesso!
🌐 Servidor HTTP rodando na porta 3000
🔗 Keep-alive ativado para evitar hibernação
```

## 📖 Como Usar

### 1️⃣ Configurar o Sistema

Use o comando `/setup` em qualquer canal:

```
/setup cargo:@Suporte categoria:📩・TICKETS
```

- **cargo**: O cargo que terá acesso aos tickets
- **categoria**: A categoria onde os canais de ticket serão criados

### 2️⃣ Enviar Painel de Tickets

Use o comando `/ticket` no canal onde deseja o painel:

```
/ticket
```

Isso enviará o embed personalizado da Astral Store com o botão de criar ticket.

### 3️⃣ Abrir um Ticket

Os usuários clicam no botão **"📩 criar ticket"** e automaticamente:
- Um canal privado é criado (`ticket-123456789`)
- Apenas o usuário e a equipe de suporte têm acesso
- Uma mensagem de boas-vindas é enviada

### 4️⃣ Fechar um Ticket

Dentro do ticket, clique no botão **"🔒 Fechar Ticket"**:
- Uma mensagem de confirmação aparece
- O canal é deletado após 5 segundos

## 🛠️ Estrutura do Projeto

```
discord-ticket-bot/
├── index.js           # Código principal do bot
├── package.json       # Dependências do projeto
├── config.json        # Configurações (criado automaticamente)
├── .env               # Variáveis de ambiente (TOKEN e CLIENT_ID)
├── .env.example       # Exemplo de .env
├── .gitignore         # Arquivos ignorados pelo git
└── README.md          # Este arquivo
```

## 🌐 Keep-Alive (Anti-Hibernação)

O bot inclui um servidor HTTP na porta 3000 que responde em:

```
http://localhost:3000
```

### Para Replit

O servidor já está configurado e funcionando automaticamente.

### Para Render/Railway

Configure um **Health Check** apontando para `/` na porta configurada.

### Logs Automáticos

A cada 5 minutos, o bot registra no console:

```
⏰ [01/11/2025, 14:30:00] Bot ativo - 1 servidores
```

Isso evita que o bot seja desligado por inatividade.

## 🎨 Personalização

### Modificar o Embed do Painel

Edite no arquivo `index.js`, na seção do comando `/ticket`:

```javascript
const embed = new EmbedBuilder()
    .setTitle('Seu Título Aqui')
    .setDescription('Sua descrição aqui')
    .setColor(0x0099FF) // Cor em hexadecimal
    .setFooter({ text: 'Seu Footer Aqui' })
```

### Modificar Emojis dos Botões

Os emojis personalizados requerem que você tenha acesso ao servidor onde estão:

```javascript
.setEmoji('<:Ticket:1404555208847134780>')
```

Para usar emojis padrão, use apenas o emoji Unicode:

```javascript
.setEmoji('🎫')
```

## 📝 Comandos Disponíveis

| Comando | Descrição | Permissão Necessária |
|---------|-----------|---------------------|
| `/setup` | Configura o sistema de tickets | Administrador |
| `/ticket` | Envia o painel de tickets | Gerenciar Canais |

## 🔧 Solução de Problemas

### ❌ Bot não responde aos comandos

1. Verifique se o bot está online
2. Certifique-se de que os comandos foram registrados (veja os logs)
3. Confirme que o bot tem as permissões necessárias

### ❌ Erro ao criar ticket

1. Verifique se `/setup` foi executado
2. Confirme que a categoria existe
3. Verifique as permissões do bot na categoria

### ❌ Botão não funciona

1. Verifique se **Message Content Intent** está ativado
2. Reinicie o bot após ativar intents
3. Verifique os logs de erro no console

## 📊 Tecnologias Utilizadas

- **Node.js** - Runtime JavaScript
- **discord.js v14** - Biblioteca para Discord
- **Express.js** - Servidor HTTP
- **dotenv** - Gerenciamento de variáveis de ambiente
- **fs** - Sistema de arquivos (nativo)

## 📄 Licença

MIT License - Sinta-se livre para modificar e usar este bot!

## 💬 Suporte

Desenvolvido com ❤️ por **Astral Store**

---

**Powered by Astral Store** 🌟
