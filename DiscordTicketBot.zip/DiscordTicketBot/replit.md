# Discord Ticket Bot - Astral Store

## 📌 Visão Geral

Bot completo de tickets para Discord desenvolvido em JavaScript (Node.js) usando discord.js v14. O bot oferece um sistema profissional de atendimento com painel personalizado, criação automática de tickets privados e sistema anti-hibernação (keep-alive).

## 🎯 Estado Atual do Projeto

**Status**: ✅ Completo e Funcional

- ✅ Bot configurado e online
- ✅ Comandos slash registrados (`/setup` e `/ticket`)
- ✅ Sistema de persistência com config.json
- ✅ Keep-alive ativo na porta 3000
- ✅ Servidor conectado a 1 servidor Discord

**Última Atualização**: 01/11/2025

## 🏗️ Arquitetura do Projeto

### Estrutura de Arquivos

```
discord-ticket-bot/
├── index.js              # Código principal do bot (351 linhas)
├── package.json          # Dependências do projeto
├── config.json           # Configurações (criado automaticamente)
├── README.md             # Documentação completa
├── .env                  # Variáveis de ambiente (TOKEN, CLIENT_ID)
├── .env.example          # Exemplo de configuração
├── .gitignore            # Arquivos ignorados pelo git
└── replit.md            # Este arquivo
```

### Tecnologias Utilizadas

- **Node.js 20** - Runtime JavaScript
- **discord.js v14.14.1** - Biblioteca oficial do Discord
- **Express.js v4.18.2** - Servidor HTTP para keep-alive
- **dotenv v16.3.1** - Gerenciamento de secrets

## 🔧 Funcionalidades Implementadas

### 1. Comando `/setup`
Configura o sistema de tickets no servidor Discord.

**Parâmetros**:
- `cargo`: Cargo que terá acesso aos tickets (ex: @Suporte)
- `categoria`: Categoria onde os tickets serão criados

**Permissão necessária**: Administrador

**Comportamento**:
- Salva as configurações no `config.json`
- Suporta múltiplos servidores (um config por guild ID)
- Retorna embed de confirmação

### 2. Comando `/ticket`
Envia o painel de tickets personalizado.

**Permissão necessária**: Gerenciar Canais

**Painel Personalizado**:
- **Título**: 🎫 Bem-vindo à Central de Atendimento!
- **Descrição**: Instruções de atendimento + horários da Astral Store
- **Cor**: Azul (`0x0099FF`)
- **Footer**: "Powered by Astral Store"
- **Botão**: "📩 criar ticket" (emoji personalizado)

### 3. Sistema de Tickets

**Criação**:
- Canal privado com nome `ticket-[userid]`
- Permissões automáticas (usuário + cargo de suporte)
- Embed de boas-vindas
- Botão "🔒 Fechar Ticket"

**Fechamento**:
- Mensagem de confirmação
- Canal deletado após 5 segundos
- Registro no console

**Proteções**:
- Impede múltiplos tickets do mesmo usuário
- Verifica se o sistema foi configurado
- Validação de permissões

### 4. Persistência de Dados

**config.json**:
```json
{
  "GUILD_ID": {
    "supportRoleId": "ID_DO_CARGO",
    "categoryId": "ID_DA_CATEGORIA"
  }
}
```

- Criado automaticamente na primeira execução
- Carregado ao iniciar o bot
- Salvo a cada alteração via `/setup`

### 5. Sistema Keep-Alive

**Servidor HTTP**:
- Porta: 3000 (configurável via `PORT`)
- Endpoint: `/` (retorna status do bot em HTML)
- Bind: 0.0.0.0 (acessível externamente)

**Tratamento de Erros**:
- Detecta porta em uso (EADDRINUSE)
- Tenta porta alternativa automaticamente
- Logs informativos de cada etapa

**Logs Automáticos**:
- A cada 5 minutos registra status do bot
- Evita hibernação em serviços cloud
- Formato: `⏰ [data/hora] Bot ativo - X servidores`

### 6. Registro de Comandos

- Usa Discord REST API v10
- Registra comandos globalmente (todos os servidores)
- Executado automaticamente ao iniciar o bot
- Comandos aparecem instantaneamente no Discord

## 🔐 Secrets Configurados

As seguintes variáveis de ambiente estão configuradas no Replit Secrets:

- `TOKEN` - Token de autenticação do bot Discord
- `CLIENT_ID` - Application ID do bot Discord
- `SESSION_SECRET` - Gerado automaticamente (não usado atualmente)

## 🚀 Como Executar

O bot está configurado para iniciar automaticamente via workflow:

```bash
node index.js
```

**Logs esperados**:
```
🌐 Servidor HTTP rodando na porta 3000
🔗 Keep-alive ativado para evitar hibernação
🤖 Bot online como NomeDoBot#1234
📊 Servidores: 1
✅ Configurações carregadas com sucesso!
🔄 Registrando comandos slash...
✅ Comandos registrados com sucesso!
```

## 📝 Preferências do Usuário

### Personalização do Embed
O usuário solicitou um painel específico com:

- **Título customizado** com emoji personalizado da Astral Store
- **Descrição detalhada** incluindo horários de atendimento:
  - Segunda a Sexta: 8:00h as 22:30h
  - Sábado e Domingo: 7:00h as 21:30h
- **Avisos** sobre atendimento fora do horário
- **Footer**: "Powered by Astral Store"
- **Cor**: Azul
- **Emojis personalizados** do servidor

### Requisitos Técnicos
- Sem MongoDB (persistência via JSON)
- Keep-alive integrado
- Código limpo e comentado
- Instruções completas de instalação

## 🛠️ Manutenção e Melhorias Futuras

### Sugestões do Arquiteto:

1. **Logs contextuais**: Adicionar mais detalhes nos logs de criação de tickets
2. **Rate limiting**: Implementar limitação de abertura de tickets por usuário
3. **Flexibilidade de portas**: Expor porta final usada via logs/environment

### Possíveis Expansões:

- Sistema de categorias/departamentos múltiplos
- Transcrição de tickets antes de fechar
- Estatísticas de atendimento
- Sistema de avaliação pós-atendimento
- Logs de histórico em arquivos

## 🐛 Solução de Problemas Comuns

1. **Bot não responde aos comandos**:
   - Verificar se Message Content Intent está ativado
   - Confirmar que TOKEN e CLIENT_ID estão corretos
   - Reiniciar o workflow

2. **Erro ao criar ticket**:
   - Executar `/setup` primeiro
   - Verificar permissões do bot na categoria
   - Confirmar que a categoria existe

3. **Porta 3000 em uso**:
   - O código tenta porta 3001 automaticamente
   - Configurar variável `PORT` se necessário

## 📊 Estatísticas

- **Linhas de código**: 365 (index.js)
- **Dependências**: 3 (discord.js, dotenv, express)
- **Comandos**: 2 (/setup, /ticket)
- **Eventos tratados**: clientReady, interactionCreate
- **Tipos de interação**: ChatInputCommand, Button

## 🔗 Links Úteis

- [Discord Developer Portal](https://discord.com/developers/applications)
- [discord.js Documentation](https://discord.js.org/)
- [Express.js Guide](https://expressjs.com/)

---

**Desenvolvido com ❤️ para Astral Store**
